import re
import tempfile
import unittest
from pathlib import Path

import app as idea_app


class IdeaHubTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.temp_dir.name) / "test_ideas.db")
        idea_app.app.config.update(TESTING=True, DATABASE=self.db_path, SECRET_KEY="test-only-secret")
        idea_app.init_db()
        self.client = idea_app.app.test_client()

    def tearDown(self):
        self.temp_dir.cleanup()

    def token(self, path="/"):
        response = self.client.get(path)
        match = re.search(rb'name="csrf_token" value="([^"]+)"', response.data)
        if not match:
            # Pages such as the homepage expose the token via the logout/register forms only
            # when those controls are present. Visit a public form to get a token.
            response = self.client.get("/register")
            match = re.search(rb'name="csrf_token" value="([^"]+)"', response.data)
        self.assertIsNotNone(match, "CSRF token should be present in a rendered form")
        return match.group(1).decode("utf-8")

    def register(self, username="tester", password="correct-horse-9"):
        token = self.token("/register")
        return self.client.post("/register", data={
            "csrf_token": token,
            "username": username,
            "password": password,
        }, follow_redirects=True)

    def test_home_has_security_headers(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("default-src 'self'", response.headers["Content-Security-Policy"])
        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(response.headers["X-Frame-Options"], "DENY")

    def test_csrf_is_required(self):
        response = self.client.post("/register", data={"username": "tester", "password": "correct-horse-9"})
        self.assertEqual(response.status_code, 400)

    def test_register_and_publish_idea(self):
        response = self.register()
        self.assertEqual(response.status_code, 200)
        token = self.token("/ideas/new")
        response = self.client.post("/ideas/new", data={
            "csrf_token": token,
            "title": "A better school library",
            "body": "Create a simple shared catalogue so students can find and recommend books.",
            "category": "Education",
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"A better school library", response.data)
        db = idea_app.get_db()
        self.assertEqual(db.execute("SELECT COUNT(*) FROM ideas").fetchone()[0], 1)

    def test_raw_markup_is_rejected(self):
        self.register()
        token = self.token("/ideas/new")
        response = self.client.post("/ideas/new", data={
            "csrf_token": token,
            "title": "<script>alert(1)</script>",
            "body": "This is a long enough idea body that would otherwise be saved.",
            "category": "Technology",
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"HTML and scripts are not allowed", response.data)
        self.assertEqual(idea_app.get_db().execute("SELECT COUNT(*) FROM ideas").fetchone()[0], 0)

    def test_stored_markup_is_escaped_if_validation_is_bypassed(self):
        db = idea_app.get_db()
        cur = db.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)", ("xssuser", "not-a-real-hash"))
        db.execute("INSERT INTO ideas (user_id, title, body, category) VALUES (?, ?, ?, ?)",
                   (cur.lastrowid, "Test title", "<script>alert(1)</script>", "Other"))
        db.commit()
        response = self.client.get("/ideas/1")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"&lt;script&gt;alert(1)&lt;/script&gt;", response.data)
        self.assertNotIn(b"<script>alert(1)</script>", response.data)


if __name__ == "__main__":
    unittest.main()
