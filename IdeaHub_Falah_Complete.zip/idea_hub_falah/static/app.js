'use strict';

// Keep interactions minimal. Never render user-submitted content with innerHTML.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-dismiss-flash]').forEach((button) => {
    button.addEventListener('click', () => {
      const message = button.closest('.flash');
      if (message) message.remove();
    });
  });

  document.querySelectorAll('[data-count-form]').forEach((form) => {
    form.querySelectorAll('[data-count-target]').forEach((field) => {
      const target = document.getElementById(field.dataset.countTarget);
      if (!target) return;
      const updateCount = () => {
        const maximum = field.getAttribute('maxlength') || '?';
        // textContent is intentionally used instead of HTML insertion.
        target.textContent = `${field.value.length} / ${maximum}`;
      };
      field.addEventListener('input', updateCount);
      updateCount();
    });
  });
});
