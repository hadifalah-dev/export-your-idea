@echo off
setlocal
cd /d "%~dp0"
echo.
echo  IDEA HUB FALAH - first launch setup
where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    set "PY=python"
)
if not exist ".venv\Scripts\python.exe" (
    echo Creating a private Python environment...
    %PY% -m venv .venv
    if errorlevel 1 goto :error
)
echo Installing required package if needed...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :error
echo.
echo Opening IdeaHub Falah at http://127.0.0.1:5000
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:5000"
echo Keep this window open while using the website. Press Ctrl+C to stop.
".venv\Scripts\python.exe" app.py
goto :eof
:error
echo.
echo Setup failed. Install Python 3.10 or newer from https://www.python.org/downloads/
echo During setup, enable the option to add Python to PATH.
pause
