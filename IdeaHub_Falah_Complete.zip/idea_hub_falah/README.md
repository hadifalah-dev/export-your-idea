# IdeaHub Falah — community idea board

A small, working idea-sharing website with a clean, modern (non-glassmorphic) interface. People can create accounts, publish ideas, comment, and rate ideas from other members. Posts are stored on disk in a SQLite database.

## Run on Windows

1. Install **Python 3.10 or newer** from <https://www.python.org/downloads/> if it is not already installed. During installation, enable **Add Python to PATH**.
2. Extract the ZIP into a normal folder, for example `Downloads\idea_hub_falah`.
3. Double-click `run_windows.bat`.
4. On the first run, it creates a private Python environment and installs Flask. An internet connection is needed for that initial package installation. The website itself does not need third-party APIs or an external database.
5. Open <http://127.0.0.1:5000> if your browser does not open automatically. Keep the black command window open while using the website. Press **Ctrl+C** in that window to stop it.

## What is included

- `app.py` — Flask backend, account login/registration, routes, validation, security headers, rate limits, and database setup.
- `templates/` — the HTML pages.
- `static/style.css` — responsive visual design.
- `static/app.js` — small UI interactions; it uses `textContent`, never `innerHTML`, for counters.
- `instance/ideas.db` — created automatically on first start. **This is the idea store.** It preserves accounts, ideas, comments, and ratings across restarts. Back up this file to back up your data.
- `run_windows.bat` — one-click Windows setup and launcher.
- `run_mac_linux.sh` — basic macOS/Linux launcher.
- `tests/test_app.py` — starter security and behaviour tests.

## Features

- Member accounts with password hashes (passwords are not saved as plain text).
- Publish ideas with a title, description, and category.
- Search, category filters, newest/top-rated/most-discussed sorting.
- Comments on ideas.
- Ratings from 1–5. Members cannot rate their own idea, and each member has one adjustable rating per idea.
- SQLite database with parameterized SQL statements.
- Request-size caps, simple in-process rate limiting, CSRF tokens, restricted usernames, text length limits, and server-side rejection of raw `<` and `>` markup characters in submitted content.
- Jinja HTML auto-escaping and a Content Security Policy that allows scripts only from this website. User-submitted content is rendered as text, not trusted as HTML.
- Security headers including `X-Content-Type-Options`, `X-Frame-Options`, and a restrictive permissions policy.

## Security notes — read before making this public

The website is deliberately designed so normal submissions cannot execute HTML or JavaScript. It rejects raw markup characters in idea titles, descriptions, and comments, automatically escapes output, avoids `innerHTML`, and sends a restrictive Content Security Policy. These layers reduce cross-site scripting (XSS) risk, but no small starter app should be described as perfectly secure.

The included Flask server is for **local development/testing**, not direct public production hosting. To preview from another device on your trusted home Wi-Fi, you can set `IDEA_HUB_HOST=0.0.0.0` before starting; allow it through Windows Firewall only if you understand the exposure. Before opening it to the public internet, deploy behind HTTPS with a production WSGI server, configure a long random `IDEA_HUB_SECRET_KEY`, set `IDEA_HUB_COOKIE_SECURE=1` when HTTPS is enabled, and replace the in-process rate limiter with a shared limiter for multi-worker deployments. Also add moderation/reporting, backups, privacy/terms pages, monitoring, and an abuse-response process. Never expose Flask's development server directly to the public internet.

### Set a secret key on Windows (optional for local use)

In Command Prompt, before starting the app:

```bat
set IDEA_HUB_SECRET_KEY=replace-this-with-a-long-random-secret
.venv\Scripts\python.exe app.py
```

For production, store secrets in your hosting platform's environment settings rather than in source code.

## Run tests

From the extracted project folder, after installing requirements:

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## Database backup

Stop the website, then copy `instance\ideas.db` to a separate safe folder. Do not delete it unless you intend to remove the saved accounts and ideas.

## Data limits / deployment notes

This is an intentionally small starter app. The basic rate limiter is in memory and resets when the process restarts. SQLite works well for a small, single-instance project; a busy public community should use a database and rate limiter suited to its hosting architecture. Uploaded content is plain text; file uploads and arbitrary HTML are not supported.
