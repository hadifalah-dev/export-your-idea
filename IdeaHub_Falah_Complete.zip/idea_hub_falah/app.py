from __future__ import annotations

import os
import re
import secrets
import sqlite3
import threading
import time
from collections import defaultdict, deque
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Callable
from urllib.parse import urlsplit

from flask import (
    Flask,
    abort,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = INSTANCE_DIR / "ideas.db"

CATEGORIES = [
    "Technology",
    "Education",
    "Environment",
    "Health",
    "Community",
    "Games",
    "Business",
    "Other",
]

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("IDEA_HUB_SECRET_KEY") or secrets.token_hex(32),
    DATABASE=str(DB_PATH),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("IDEA_HUB_COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=24 * 1024,
    DEBUG=False,
)

# Lightweight in-process abuse throttling. For a public, multi-worker deployment,
# replace this with a shared store (such as Redis) and configure a reverse proxy.
_rate_lock = threading.Lock()
_rate_hits: dict[str, deque[float]] = defaultdict(deque)

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS ideas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    category TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ideas_created ON ideas(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ideas_category ON ideas(category);
CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    idea_id INTEGER NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_comments_idea ON comments(idea_id, created_at DESC);
CREATE TABLE IF NOT EXISTS ratings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    idea_id INTEGER NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL CHECK(score BETWEEN 1 AND 5),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(idea_id, user_id)
);
"""


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        db = sqlite3.connect(app.config["DATABASE"], timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        db.execute("PRAGMA busy_timeout = 10000")
        g.db = db
    return g.db


@app.teardown_appcontext
def close_db(_error: BaseException | None = None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    db = sqlite3.connect(app.config["DATABASE"], timeout=10)
    try:
        db.executescript(SCHEMA)
        db.commit()
    finally:
        db.close()


init_db()


def _csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


@app.context_processor
def inject_template_values() -> dict[str, object]:
    return {
        "csrf_token": _csrf_token(),
        "current_user": current_user(),
        "categories": CATEGORIES,
    }


def current_user() -> sqlite3.Row | None:
    user_id = session.get("user_id")
    if not user_id:
        return None
    return get_db().execute(
        "SELECT id, username FROM users WHERE id = ?", (user_id,)
    ).fetchone()


def login_required(view: Callable) -> Callable:
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            flash("Please sign in to do that.", "info")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def enforce_rate_limit(bucket: str, limit: int, window_seconds: int) -> bool:
    now = time.monotonic()
    identity = request.remote_addr or "unknown"
    account_id = session.get("user_id", "guest")
    key = f"{bucket}:{identity}:{account_id}"
    with _rate_lock:
        hits = _rate_hits[key]
        while hits and now - hits[0] > window_seconds:
            hits.popleft()
        if len(hits) >= limit:
            return False
        hits.append(now)
        if len(_rate_hits) > 4000:
            for old_key in list(_rate_hits.keys())[:1000]:
                old_hits = _rate_hits[old_key]
                while old_hits and now - old_hits[0] > window_seconds:
                    old_hits.popleft()
                if not old_hits:
                    _rate_hits.pop(old_key, None)
    return True


@app.before_request
def protect_requests() -> None:
    # CSRF validation on every state-changing form, using a per-session random token.
    if request.method == "POST":
        supplied = request.form.get("csrf_token", "")
        expected = session.get("csrf_token", "")
        if not supplied or not expected or not secrets.compare_digest(supplied, expected):
            abort(400, description="This form expired or could not be verified. Refresh and try again.")

    if request.method == "POST":
        path = request.path
        if path in ("/login", "/register"):
            limit, window, bucket = 12, 300, "auth"
        elif path == "/ideas/new":
            limit, window, bucket = 5, 300, "idea"
        elif path.endswith("/comments"):
            limit, window, bucket = 18, 300, "comment"
        elif path.endswith("/rate"):
            limit, window, bucket = 40, 300, "rating"
        else:
            limit, window, bucket = 80, 300, "other"
        if not enforce_rate_limit(bucket, limit, window):
            abort(429, description="Too many requests. Please wait a few minutes and try again.")


@app.after_request
def add_security_headers(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; "
        "img-src 'self' data:; font-src 'self'; connect-src 'self'; "
        "object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response


def validate_plain_text(value: str, *, field: str, max_length: int, min_length: int = 1,
                        multiline: bool = False) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} is required.")
    cleaned = value.replace("\r\n", "\n").replace("\r", "\n").strip()
    if len(cleaned) < min_length:
        raise ValueError(f"{field} must be at least {min_length} character(s).")
    if len(cleaned) > max_length:
        raise ValueError(f"{field} must be {max_length} characters or fewer.")
    # Reject markup characters instead of attempting to sanitize arbitrary HTML.
    # Jinja auto-escaping and CSP still protect rendering if a payload gets stored.
    if "<" in cleaned or ">" in cleaned:
        raise ValueError(f"{field} must be plain text. HTML and scripts are not allowed.")
    allowed_newlines = "\n\t" if multiline else ""
    if any(ord(ch) < 32 and ch not in allowed_newlines for ch in cleaned):
        raise ValueError(f"{field} contains unsupported control characters.")
    if not multiline and "\n" in cleaned:
        raise ValueError(f"{field} must be a single line.")
    return cleaned


def get_idea_or_404(idea_id: int) -> sqlite3.Row:
    idea = get_db().execute(
        """
        SELECT i.id, i.user_id, i.title, i.body, i.category, i.created_at,
               u.username,
               COALESCE(ROUND(AVG(r.score), 1), 0) AS average_rating,
               COUNT(DISTINCT r.id) AS rating_count,
               COUNT(DISTINCT c.id) AS comment_count
        FROM ideas i
        JOIN users u ON u.id = i.user_id
        LEFT JOIN ratings r ON r.idea_id = i.id
        LEFT JOIN comments c ON c.idea_id = i.id
        WHERE i.id = ?
        GROUP BY i.id
        """,
        (idea_id,),
    ).fetchone()
    if idea is None:
        abort(404)
    return idea


@app.template_filter("pretty_date")
def pretty_date(value: str | None) -> str:
    if not value:
        return "Recently"
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.strftime("%d %b %Y")
    except (ValueError, TypeError):
        return value


@app.route("/")
def index():
    db = get_db()
    query = request.args.get("q", "").strip()[:80]
    category = request.args.get("category", "")
    sort = request.args.get("sort", "new")
    if category not in CATEGORIES:
        category = ""
    if sort not in ("new", "top", "discussed"):
        sort = "new"

    conditions: list[str] = []
    params: list[object] = []
    if query:
        conditions.append("(i.title LIKE ? OR i.body LIKE ? OR u.username LIKE ?)")
        term = f"%{query}%"
        params.extend((term, term, term))
    if category:
        conditions.append("i.category = ?")
        params.append(category)
    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    ordering = {
        "new": "i.created_at DESC, i.id DESC",
        "top": "average_rating DESC, rating_count DESC, i.created_at DESC",
        "discussed": "comment_count DESC, i.created_at DESC",
    }[sort]
    ideas = db.execute(
        f"""
        SELECT i.id, i.title, i.body, i.category, i.created_at, u.username,
               COALESCE(ROUND(AVG(r.score), 1), 0) AS average_rating,
               COUNT(DISTINCT r.id) AS rating_count,
               COUNT(DISTINCT c.id) AS comment_count
        FROM ideas i
        JOIN users u ON u.id = i.user_id
        LEFT JOIN ratings r ON r.idea_id = i.id
        LEFT JOIN comments c ON c.idea_id = i.id
        {where}
        GROUP BY i.id
        ORDER BY {ordering}
        LIMIT 100
        """,
        params,
    ).fetchall()
    stats = db.execute(
        "SELECT (SELECT COUNT(*) FROM ideas) AS ideas, "
        "(SELECT COUNT(*) FROM users) AS members, "
        "(SELECT COUNT(*) FROM comments) AS comments"
    ).fetchone()
    return render_template(
        "index.html", ideas=ideas, query=query, selected_category=category,
        sort=sort, stats=stats,
    )


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user():
        return redirect(url_for("index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
            flash("Username must be 3–20 characters: letters, numbers, and underscores only.", "error")
        elif len(password) < 10 or len(password) > 128:
            flash("Use a password between 10 and 128 characters.", "error")
        else:
            db = get_db()
            try:
                cursor = db.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, generate_password_hash(password)),
                )
                db.commit()
            except sqlite3.IntegrityError:
                flash("That username is already taken. Try another one.", "error")
            else:
                session.clear()
                session["user_id"] = cursor.lastrowid
                session["csrf_token"] = secrets.token_urlsafe(32)
                flash("Welcome! Your account is ready.", "success")
                return redirect(url_for("index"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute(
            "SELECT id, username, password_hash FROM users WHERE username = ? COLLATE NOCASE",
            (username,),
        ).fetchone()
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Username or password is incorrect.", "error")
        else:
            session.clear()
            session["user_id"] = user["id"]
            session["csrf_token"] = secrets.token_urlsafe(32)
            flash("You're signed in.", "success")
            next_url = request.args.get("next", "")
            # Only allow same-site absolute paths; reject backslashes and URL authorities.
            parsed_next = urlsplit(next_url)
            safe_next = (
                next_url.startswith("/") and not next_url.startswith("//")
                and "\\" not in next_url and not parsed_next.scheme
                and not parsed_next.netloc
                and not any(ord(ch) < 32 for ch in next_url)
            )
            if safe_next:
                return redirect(next_url)
            return redirect(url_for("index"))
    return render_template("login.html")


@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("You have signed out.", "info")
    return redirect(url_for("index"))


@app.route("/ideas/new", methods=["GET", "POST"])
@login_required
def new_idea():
    if request.method == "POST":
        try:
            title = validate_plain_text(
                request.form.get("title", ""), field="Title", max_length=90, min_length=5
            )
            body = validate_plain_text(
                request.form.get("body", ""), field="Idea description", max_length=4000,
                min_length=20, multiline=True
            )
            category = request.form.get("category", "Other")
            if category not in CATEGORIES:
                raise ValueError("Choose a category from the list.")
        except ValueError as exc:
            flash(str(exc), "error")
        else:
            db = get_db()
            cursor = db.execute(
                "INSERT INTO ideas (user_id, title, body, category) VALUES (?, ?, ?, ?)",
                (session["user_id"], title, body, category),
            )
            db.commit()
            flash("Your idea has been published.", "success")
            return redirect(url_for("idea_detail", idea_id=cursor.lastrowid))
    return render_template("new_idea.html")


@app.route("/ideas/<int:idea_id>")
def idea_detail(idea_id: int):
    db = get_db()
    idea = get_idea_or_404(idea_id)
    comments = db.execute(
        """
        SELECT c.id, c.body, c.created_at, u.username, c.user_id
        FROM comments c JOIN users u ON u.id = c.user_id
        WHERE c.idea_id = ? ORDER BY c.created_at DESC, c.id DESC LIMIT 200
        """,
        (idea_id,),
    ).fetchall()
    my_rating = None
    viewer = current_user()
    if viewer:
        row = db.execute(
            "SELECT score FROM ratings WHERE idea_id = ? AND user_id = ?",
            (idea_id, viewer["id"]),
        ).fetchone()
        my_rating = row["score"] if row else None
    return render_template(
        "idea_detail.html", idea=idea, comments=comments, my_rating=my_rating
    )


@app.post("/ideas/<int:idea_id>/comments")
@login_required
def add_comment(idea_id: int):
    get_idea_or_404(idea_id)
    try:
        body = validate_plain_text(
            request.form.get("body", ""), field="Comment", max_length=1000,
            min_length=2, multiline=True
        )
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("idea_detail", idea_id=idea_id) + "#comments")
    db = get_db()
    db.execute(
        "INSERT INTO comments (idea_id, user_id, body) VALUES (?, ?, ?)",
        (idea_id, session["user_id"], body),
    )
    db.commit()
    flash("Comment added.", "success")
    return redirect(url_for("idea_detail", idea_id=idea_id) + "#comments")


@app.post("/ideas/<int:idea_id>/rate")
@login_required
def rate_idea(idea_id: int):
    idea = get_idea_or_404(idea_id)
    if idea["user_id"] == session["user_id"]:
        flash("You cannot rate your own idea. Invite someone else to review it.", "error")
        return redirect(url_for("idea_detail", idea_id=idea_id))
    raw_score = request.form.get("score", "")
    if raw_score not in {"1", "2", "3", "4", "5"}:
        flash("Choose a rating from 1 to 5.", "error")
        return redirect(url_for("idea_detail", idea_id=idea_id))
    db = get_db()
    db.execute(
        """
        INSERT INTO ratings (idea_id, user_id, score) VALUES (?, ?, ?)
        ON CONFLICT(idea_id, user_id) DO UPDATE SET score = excluded.score,
            created_at = datetime('now')
        """,
        (idea_id, session["user_id"], int(raw_score)),
    )
    db.commit()
    flash("Your rating has been saved.", "success")
    return redirect(url_for("idea_detail", idea_id=idea_id))


@app.errorhandler(400)
def bad_request(error):
    message = getattr(error, "description", "That request could not be verified.")
    return render_template("error.html", code=400, heading="Request not verified", message=message), 400


@app.errorhandler(404)
def not_found(_error):
    return render_template(
        "error.html", code=404, heading="Idea not found",
        message="That page does not exist, or the idea may have been removed.",
    ), 404


@app.errorhandler(429)
def too_many_requests(error):
    message = getattr(error, "description", "Please slow down and try again.")
    return render_template("error.html", code=429, heading="Take a quick breather", message=message), 429


@app.errorhandler(413)
def too_large(_error):
    return render_template(
        "error.html", code=413, heading="That submission is too large",
        message="Please shorten the text and submit again.",
    ), 413


if __name__ == "__main__":
    # Local development server only. Use a production WSGI server for public deployment.
    print("\nIdeaHub Falah is running at http://127.0.0.1:5000\n")
    app.run(host=os.environ.get("IDEA_HUB_HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")), debug=False)
